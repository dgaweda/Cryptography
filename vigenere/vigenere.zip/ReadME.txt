Projekt został napisany w języku C#.

Kryptoanaliza nie działa.

Ścieżka do folderu gdzie są pliki .txt
vigenere\bin\Debug\netcoreapp3.1